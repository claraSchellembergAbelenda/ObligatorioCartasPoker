
package pokerApp.Sistemas;

import pokerApp.juego.Mano;

public class SistemaManos {
    Mano manoActual;
    
    public void inicializarMano(){
        
    }
    public void realizarApuestas(){
        
    }
    public void cambiarCartas(){
        //en realidad tal vez deberiamos tener un sistema de cartas que haga los cambios respectivos, que tenga
        //el mazo de la mano y ahi hacer las operaciones tales como el cambio de cartas
    }
    public void determinarGanador(){
        
    }
    public void finalizarMano(){
        
    }
    
}
