
package pokerApp.figurasYCartas;

public class Escalera extends TipoFigura {
    
}
