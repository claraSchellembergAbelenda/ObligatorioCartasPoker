
package pokerApp.figurasYCartas;

public abstract class TipoFigura {
        
}
