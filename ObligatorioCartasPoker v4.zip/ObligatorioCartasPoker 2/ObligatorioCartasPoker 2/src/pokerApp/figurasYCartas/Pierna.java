
package pokerApp.figurasYCartas;

public class Pierna extends TipoFigura {
    
}
