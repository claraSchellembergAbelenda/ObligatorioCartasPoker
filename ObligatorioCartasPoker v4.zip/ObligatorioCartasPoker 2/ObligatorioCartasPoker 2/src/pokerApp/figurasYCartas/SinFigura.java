
package pokerApp.figurasYCartas;

public class SinFigura extends TipoFigura {
    
}
