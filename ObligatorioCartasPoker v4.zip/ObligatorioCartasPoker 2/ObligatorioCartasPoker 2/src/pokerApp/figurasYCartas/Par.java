
package pokerApp.figurasYCartas;

public class Par extends TipoFigura {
    
}
