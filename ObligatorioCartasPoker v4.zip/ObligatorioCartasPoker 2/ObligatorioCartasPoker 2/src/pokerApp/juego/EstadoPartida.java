
package pokerApp.juego;


public enum EstadoPartida {
    ABIERTA,
    JUGANDO,
    FINALIZADA;
}

